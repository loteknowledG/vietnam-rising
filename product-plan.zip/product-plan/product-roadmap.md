# Product Roadmap

## Sections

### 1. HCMC Hub
The flagship design experience featuring Landmark 81 and real React developer job feeds for Ho Chi Minh City.

### 2. Hanoi Hub
The capital city showcase, utilizing Landmark 72 and a focus on high-contrast, city-specific job listings.

### 3. Da Nang Hub
The central coast showcase, featuring Da Nang Downtown and highlighting tech opportunities in the region's rising hub.
