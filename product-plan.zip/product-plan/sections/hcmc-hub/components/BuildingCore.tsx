export function BuildingCore() {
    return (
        <div className="absolute left-1/2 -translate-x-1/2 top-0 bottom-0 w-full max-w-lg pointer-events-none flex items-end justify-center mb-[-2px]">
            {/*
              Landmark 81 (night) vibe:
              - Tall slender shaft with warm vertical light lines
              - Violet crown and spire glow at the top
            */}

            {/* Subtle outer silhouette wings */}
            <div className="relative h-[55%] w-12 bg-gradient-to-t from-amber-900/70 via-amber-700/30 to-transparent opacity-30 mx-1 rounded-t-sm" />
            <div className="relative h-[65%] w-14 bg-gradient-to-t from-amber-900/70 via-amber-700/30 to-transparent opacity-35 mx-1 rounded-t-sm" />

            {/* Main tower */}
            <div className="relative h-full w-48 flex flex-col items-center justify-end z-10">
                {/* Spire */}
                <div className="w-2 h-40 -mb-6 bg-gradient-to-t from-violet-800 via-violet-600 to-violet-300 rounded-t-full opacity-90" />

                {/* Crown */}
                <div className="relative w-40 h-28 bg-gradient-to-t from-violet-900 via-violet-700 to-violet-400 rounded-t-xl opacity-90 overflow-hidden">
                    <div className="absolute inset-0 bg-[repeating-linear-gradient(90deg,transparent,transparent_10px,rgba(255,255,255,0.15)_10px,rgba(255,255,255,0.15)_12px)]" />
                </div>

                {/* Shaft (gold lights) */}
                <div className="relative w-40 flex-1 bg-gradient-to-t from-amber-900/70 via-amber-700/40 to-stone-200/5 rounded-t-lg overflow-hidden">
                    {/* Dense vertical light strips */}
                    <div className="absolute inset-0 grid grid-cols-10 opacity-90">
                        {Array.from({ length: 10 }).map((_, i) => (
                            <div
                                key={i}
                                className={
                                    i % 3 === 0
                                        ? 'bg-gradient-to-t from-transparent via-amber-100/50 to-white/80'
                                        : 'bg-gradient-to-t from-transparent via-amber-200/30 to-white/60'
                                }
                            />
                        ))}
                    </div>

                    {/* Window noise */}
                    <div className="absolute inset-0 opacity-35 bg-[repeating-linear-gradient(0deg,transparent,transparent_6px,rgba(0,0,0,0.25)_6px,rgba(0,0,0,0.25)_7px)]" />
                </div>
            </div>

            <div className="relative h-[65%] w-14 bg-gradient-to-t from-amber-900/70 via-amber-700/30 to-transparent opacity-35 mx-1 rounded-t-sm" />
            <div className="relative h-[55%] w-12 bg-gradient-to-t from-amber-900/70 via-amber-700/30 to-transparent opacity-30 mx-1 rounded-t-sm" />
        </div>
    )
}
