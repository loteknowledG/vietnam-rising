// Aggregate types entrypoint (per-section types are under product-plan/sections/*/types.ts)

export type SectionId = 'danang-hub' | 'hanoi-hub' | 'hcmc-hub'
