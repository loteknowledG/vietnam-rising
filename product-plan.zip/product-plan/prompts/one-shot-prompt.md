# One-Shot Implementation Prompt

You are implementing the exported product design into an existing codebase.

## Context Files
- product-overview.md
- instructions/one-shot-instructions.md

## Instructions
1. Ask clarifying questions about: auth, user model, tech stack, routing, persistence.
2. Implement milestone by milestone as described in the instructions doc.
3. Write tests as you go, using the per-section tests.md files.

Begin by summarizing the product and proposing a build plan.
