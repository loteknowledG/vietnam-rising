# Section Implementation Prompt (Template)

Fill these in before sending to your coding agent:

- SECTION_ID: <section-id>
- SECTION_NAME: <section title>
- NN: <instruction number, e.g. 03>

## Context Files
- product-overview.md
- instructions/incremental/01-foundation.md
- instructions/incremental/02-shell.md
- instructions/incremental/NN-SECTION_ID.md
- sections/SECTION_ID/README.md
- sections/SECTION_ID/tests.md

Ask clarifying questions, then implement the milestone with tests.
