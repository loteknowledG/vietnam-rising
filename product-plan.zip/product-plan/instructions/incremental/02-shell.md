# 02 — Shell

Implement the application shell using the exported shell components:

- shell/README.md
- shell/components/*

Deliverables:
- AppShell layout wraps content
- Navigation structure matches the design
