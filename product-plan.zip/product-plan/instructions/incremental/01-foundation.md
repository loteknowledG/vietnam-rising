# 01 — Foundation

Implement the foundation for the product:

- Design tokens (see design-system/tokens.css, colors.json, typography.json)
- Data model scaffolding (see data-model/README.md and data-model/types.ts)
- Project setup: routing, state management, API client pattern

Deliverables:
- App boots and routes render
- Theme tokens applied
- Basic project structure ready for sections
