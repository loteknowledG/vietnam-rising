# 05 — hcmc-hub

Implement section: hcmc-hub

Inputs:
- sections/hcmc-hub/README.md
- sections/hcmc-hub/components/*
- sections/hcmc-hub/types.ts
- sections/hcmc-hub/sample-data.json
- sections/hcmc-hub/tests.md

Deliverables:
- Wire UI components into the product codebase (props-driven)
- Implement API calls + loading/error/empty states
- Add routing and navigation to reach this section
- Write tests per tests.md
