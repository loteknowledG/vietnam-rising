# 04 — hanoi-hub

Implement section: hanoi-hub

Inputs:
- sections/hanoi-hub/README.md
- sections/hanoi-hub/components/*
- sections/hanoi-hub/types.ts
- sections/hanoi-hub/sample-data.json
- sections/hanoi-hub/tests.md

Deliverables:
- Wire UI components into the product codebase (props-driven)
- Implement API calls + loading/error/empty states
- Add routing and navigation to reach this section
- Write tests per tests.md
