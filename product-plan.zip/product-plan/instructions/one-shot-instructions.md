# One-Shot Instructions
This document combines all incremental milestones.
## Milestones
- 01 — Foundation (instructions/incremental/01-foundation.md)
- 02 — Shell (instructions/incremental/02-shell.md)
- 03 — 03-danang-hub.md (instructions/incremental/03-danang-hub.md)
- 04 — 04-hanoi-hub.md (instructions/incremental/04-hanoi-hub.md)
- 05 — 05-hcmc-hub.md (instructions/incremental/05-hcmc-hub.md)
