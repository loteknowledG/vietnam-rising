# Tailwind Colors

Selected palette (Tailwind built-ins):

- Primary: lime
- Secondary: fuchsia
- Neutral: stone

Apply these consistently in your product codebase using Tailwind utility classes.
