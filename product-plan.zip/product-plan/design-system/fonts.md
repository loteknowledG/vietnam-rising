# Fonts

- Heading: Space Grotesk
- Body: Inter
- Mono: IBM Plex Mono

Use your framework's font loading approach (e.g. Next.js font optimization or a standard <link rel="preconnect"> + Google Fonts import).
